'use strict';

angular.module('yijing')
   .controller('NavCtrl', [ '$scope', '$routeParams', '$window', function ($scope, $routeParams, $window) {

   }]);
